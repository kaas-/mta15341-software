#pragma once
#ifndef TILE_H
#define TILE_H

class Tile
{
public:
	//interface for the enumeration list
	enum Type { FOREST, DESERT, MOUNTAINS, SWAMPS, BADLANDS, LAKES, PLAINS, RIVER };
};
#endif